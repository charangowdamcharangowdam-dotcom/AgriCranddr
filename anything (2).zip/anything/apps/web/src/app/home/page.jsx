"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  Cloud,
  Droplets,
  Wind,
  Thermometer,
  Leaf,
  TrendingUp,
  ShoppingCart,
  User,
} from "lucide-react";

export default function HomePage() {
  const [user, setUser] = useState(null);
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
      // Simulate weather data
      setWeather({
        temp: 28,
        humidity: 65,
        rainfall: 12,
        wind: 8,
        condition: "Partly Cloudy",
        suggestion:
          "Light rainfall expected tomorrow — suitable for tomato cultivation",
      });
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("agri_user");
    window.location.href = "/";
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-0">
              <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                AGRI
              </div>
              <div className="text-xl font-light text-white bg-black px-3 py-1">
                CRANDDR
              </div>
            </div>

            {/* Navigation Links */}
            <div className="hidden md:flex items-center gap-8">
              <a
                href="/home"
                className="text-gray-900 font-medium hover:text-green-700 transition-colors"
              >
                Home
              </a>
              <a
                href="/cropsense"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                CropSense AI
              </a>
              <a
                href="/agriride"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                AgriRide
              </a>
              <a
                href="/sathi"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                Cranddr Sathi
              </a>
              <a
                href="/marketplace"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                Marketplace
              </a>
              <a
                href="/schemes"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                Schemes
              </a>
              <a
                href="/weather"
                className="text-gray-600 hover:text-green-700 transition-colors"
              >
                Weather
              </a>
            </div>

            {/* Right Side */}
            <div className="flex items-center gap-4">
              <a
                href="/cart"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors relative"
              >
                <ShoppingCart className="w-5 h-5 text-gray-700" />
                <span className="absolute -top-1 -right-1 bg-green-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  0
                </span>
              </a>
              <div className="relative group">
                <button className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 rounded-lg transition-colors">
                  <User className="w-5 h-5 text-gray-700" />
                  <span className="text-gray-700 font-medium">{user.name}</span>
                </button>
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-4 py-3 hover:bg-gray-50 text-gray-700 rounded-lg"
                  >
                    Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1
            className="text-5xl font-light text-gray-900 mb-3"
            style={{ fontFamily: "SF Pro Display, Inter, sans-serif" }}
          >
            Hello, {user.name}
          </h1>
          <p className="text-xl text-gray-600 font-light mb-12">
            AI-powered smart farming ecosystem at your fingertips
          </p>

          {/* Weather Dashboard */}
          {weather && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 mb-12">
              <h2 className="text-2xl font-light text-gray-900 mb-6">
                Today's Weather & Insights
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div className="flex items-center gap-4 p-4 bg-gradient-to-br from-orange-50 to-orange-100/50 rounded-xl">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <Thermometer className="w-6 h-6 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Temperature</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {weather.temp}°C
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <Droplets className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Humidity</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {weather.humidity}%
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-gradient-to-br from-cyan-50 to-cyan-100/50 rounded-xl">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <Cloud className="w-6 h-6 text-cyan-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Rainfall</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {weather.rainfall}mm
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 bg-gradient-to-br from-teal-50 to-teal-100/50 rounded-xl">
                  <div className="p-3 bg-white rounded-lg shadow-sm">
                    <Wind className="w-6 h-6 text-teal-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Wind Speed</p>
                    <p className="text-2xl font-semibold text-gray-900">
                      {weather.wind} km/h
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl p-6">
                <div className="flex items-start gap-3">
                  <Leaf className="w-6 h-6 text-green-700 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">
                      AI Recommendation
                    </h3>
                    <p className="text-gray-700">{weather.suggestion}</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Feature Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <motion.a
              href="/cropsense"
              whileHover={{ y: -5, shadow: "0 20px 40px rgba(0,0,0,0.1)" }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 cursor-pointer hover:border-green-300 transition-all"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-green-100 to-green-200 rounded-xl flex items-center justify-center mb-4">
                <Leaf className="w-7 h-7 text-green-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                CropSense AI
              </h3>
              <p className="text-gray-600 font-light">
                AI-powered crop disease detection with instant diagnosis and
                treatment recommendations
              </p>
            </motion.a>

            <motion.a
              href="/agriride"
              whileHover={{ y: -5, shadow: "0 20px 40px rgba(0,0,0,0.1)" }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 cursor-pointer hover:border-green-300 transition-all"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center mb-4">
                <TrendingUp className="w-7 h-7 text-blue-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                AgriRide
              </h3>
              <p className="text-gray-600 font-light">
                Rent tractors and farming equipment from verified providers near
                you
              </p>
            </motion.a>

            <motion.a
              href="/marketplace"
              whileHover={{ y: -5, shadow: "0 20px 40px rgba(0,0,0,0.1)" }}
              transition={{ duration: 0.3 }}
              className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 cursor-pointer hover:border-green-300 transition-all"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-orange-100 to-orange-200 rounded-xl flex items-center justify-center mb-4">
                <ShoppingCart className="w-7 h-7 text-orange-700" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                Farm Direct
              </h3>
              <p className="text-gray-600 font-light">
                Sell your produce directly to consumers and get the best prices
              </p>
            </motion.a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
