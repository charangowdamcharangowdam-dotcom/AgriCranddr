"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  Upload,
  Leaf,
  AlertCircle,
  CheckCircle,
  Download,
  ArrowLeft,
} from "lucide-react";

export default function CropSensePage() {
  const [user, setUser] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
        setResult(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const analyzeImage = () => {
    setAnalyzing(true);

    // Simulate AI analysis
    setTimeout(() => {
      setResult({
        disease: "Early Blight",
        confidence: 94.5,
        crop: "Tomato",
        severity: "Moderate",
        fertilizers: ["NPK 19-19-19", "Calcium Nitrate", "Potassium Sulfate"],
        pesticides: ["Mancozeb 75% WP", "Chlorothalonil", "Azoxystrobin"],
        prevention: [
          "Remove infected leaves immediately",
          "Ensure proper spacing between plants",
          "Avoid overhead watering",
          "Apply mulch to prevent soil splash",
        ],
        organic: [
          "Neem oil spray (5ml per liter)",
          "Baking soda solution",
          "Copper-based fungicides",
          "Compost tea application",
        ],
      });
      setAnalyzing(false);
    }, 3000);
  };

  const downloadReport = () => {
    alert("Report downloaded successfully!");
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              CropSense AI
            </h1>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-green-100 to-green-200 rounded-2xl mb-4">
              <Leaf className="w-8 h-8 text-green-700" />
            </div>
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              AI Crop Disease Detection
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Upload a photo of your crop for instant AI-powered diagnosis
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Upload Section */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">
                Upload Crop Image
              </h2>

              <div className="mb-6">
                <label className="block w-full">
                  <div
                    className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all ${
                      selectedImage
                        ? "border-green-400 bg-green-50"
                        : "border-gray-300 hover:border-green-400 hover:bg-gray-50"
                    }`}
                  >
                    {selectedImage ? (
                      <div>
                        <img
                          src={selectedImage}
                          alt="Selected crop"
                          className="max-h-64 mx-auto rounded-lg mb-4"
                        />
                        <p className="text-green-700 font-medium">
                          Image uploaded successfully
                        </p>
                      </div>
                    ) : (
                      <div>
                        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-700 font-medium mb-1">
                          Click to upload crop image
                        </p>
                        <p className="text-sm text-gray-500">
                          PNG, JPG up to 10MB
                        </p>
                      </div>
                    )}
                  </div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Crop Type
                </label>
                <select className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                  <option>Tomato</option>
                  <option>Rice</option>
                  <option>Wheat</option>
                  <option>Cotton</option>
                  <option>Corn</option>
                  <option>Chilli</option>
                  <option>Potato</option>
                  <option>Banana</option>
                  <option>Sugarcane</option>
                  <option>Coffee</option>
                  <option>Tea</option>
                  <option>Rubber</option>
                  <option>Coconut</option>
                  <option>Mango</option>
                  <option>Grapes</option>
                  <option>Pomegranate</option>
                  <option>Onion</option>
                  <option>Garlic</option>
                  <option>Ginger</option>
                  <option>Turmeric</option>
                  <option>Cardamom</option>
                  <option>Black Pepper</option>
                  <option>Soybean</option>
                  <option>Groundnut</option>
                  <option>Sunflower</option>
                  <option>Mustard</option>
                  <option>Sesame</option>
                  <option>Castor</option>
                  <option>Jute</option>
                  <option>Tobacco</option>
                  <option>Areca Nut</option>
                  <option>Cashew</option>
                  <option>Papaya</option>
                  <option>Guava</option>
                  <option>Sapota</option>
                </select>
              </div>

              <button
                onClick={analyzeImage}
                disabled={!selectedImage || analyzing}
                className="w-full bg-black text-white py-4 rounded-lg font-medium hover:bg-gray-800 transition-all duration-300 hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {analyzing ? (
                  <span className="flex items-center justify-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Analyzing with AI...
                  </span>
                ) : (
                  "Analyze Crop"
                )}
              </button>
            </div>

            {/* Results Section */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-6">
                Analysis Results
              </h2>

              {!result && !analyzing && (
                <div className="text-center py-12">
                  <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">
                    Upload and analyze an image to see results
                  </p>
                </div>
              )}

              {analyzing && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 border-4 border-green-200 border-t-green-600 rounded-full animate-spin mx-auto mb-4" />
                  <p className="text-gray-700 font-medium">
                    AI is analyzing your crop...
                  </p>
                  <p className="text-sm text-gray-500 mt-2">
                    This may take a few seconds
                  </p>
                </div>
              )}

              {result && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  className="space-y-6"
                >
                  {/* Disease Detection */}
                  <div className="bg-gradient-to-br from-red-50 to-orange-50 border border-red-200 rounded-xl p-6">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-gray-900 text-lg">
                          {result.disease}
                        </h3>
                        <p className="text-sm text-gray-600">
                          Detected in {result.crop}
                        </p>
                      </div>
                      <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-medium">
                        {result.severity}
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">
                          Confidence
                        </span>
                        <span className="text-sm font-semibold text-gray-900">
                          {result.confidence}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-gradient-to-r from-green-500 to-green-600 h-2 rounded-full transition-all duration-1000"
                          style={{ width: `${result.confidence}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Recommendations */}
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      Recommended Fertilizers
                    </h4>
                    <ul className="space-y-2">
                      {result.fertilizers.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-center gap-2 text-gray-700 bg-gray-50 px-4 py-2 rounded-lg"
                        >
                          <span className="w-1.5 h-1.5 bg-green-600 rounded-full" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-blue-600" />
                      Recommended Pesticides
                    </h4>
                    <ul className="space-y-2">
                      {result.pesticides.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-center gap-2 text-gray-700 bg-gray-50 px-4 py-2 rounded-lg"
                        >
                          <span className="w-1.5 h-1.5 bg-blue-600 rounded-full" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <Leaf className="w-5 h-5 text-green-600" />
                      Organic Treatments
                    </h4>
                    <ul className="space-y-2">
                      {result.organic.map((item, idx) => (
                        <li
                          key={idx}
                          className="flex items-center gap-2 text-gray-700 bg-green-50 px-4 py-2 rounded-lg"
                        >
                          <span className="w-1.5 h-1.5 bg-green-600 rounded-full" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={downloadReport}
                    className="w-full bg-green-600 text-white py-3 rounded-lg font-medium hover:bg-green-700 transition-all duration-300 flex items-center justify-center gap-2"
                  >
                    <Download className="w-5 h-5" />
                    Download Full Report
                  </button>
                </motion.div>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
