"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  ShoppingCart,
  Star,
  MapPin,
  Plus,
  Minus,
} from "lucide-react";

const products = [
  // Vegetables
  {
    id: 1,
    name: "Fresh Tomatoes",
    farmer: "Rajesh Kumar",
    image:
      "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?q=80&w=800",
    price: 45,
    unit: "kg",
    stock: 150,
    rating: 4.8,
    location: "Bangalore Rural",
    category: "Vegetables",
  },
  {
    id: 2,
    name: "Green Chillies",
    farmer: "Manjunath Gowda",
    image:
      "https://images.unsplash.com/photo-1583663848850-46af132dc08e?q=80&w=800",
    price: 80,
    unit: "kg",
    stock: 75,
    rating: 4.6,
    location: "Tumkur",
    category: "Vegetables",
  },
  {
    id: 3,
    name: "Fresh Potatoes",
    farmer: "Ramesh Reddy",
    image:
      "https://images.unsplash.com/photo-1518977676601-b53f82aba655?q=80&w=800",
    price: 30,
    unit: "kg",
    stock: 300,
    rating: 4.5,
    location: "Kolar",
    category: "Vegetables",
  },
  {
    id: 4,
    name: "Onions",
    farmer: "Prakash Rao",
    image:
      "https://images.unsplash.com/photo-1618512496248-a07fe83aa8cb?q=80&w=800",
    price: 35,
    unit: "kg",
    stock: 250,
    rating: 4.7,
    location: "Belgaum",
    category: "Vegetables",
  },
  {
    id: 5,
    name: "Carrots",
    farmer: "Sunita Devi",
    image:
      "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?q=80&w=800",
    price: 50,
    unit: "kg",
    stock: 120,
    rating: 4.6,
    location: "Shimoga",
    category: "Vegetables",
  },
  {
    id: 6,
    name: "Cauliflower",
    farmer: "Ravi Kumar",
    image:
      "https://images.unsplash.com/photo-1568584711271-e0e4f7e9b8e1?q=80&w=800",
    price: 40,
    unit: "kg",
    stock: 100,
    rating: 4.5,
    location: "Hassan",
    category: "Vegetables",
  },
  {
    id: 7,
    name: "Cabbage",
    farmer: "Geetha Patil",
    image:
      "https://images.unsplash.com/photo-1594282486552-05b4d80fbb9f?q=80&w=800",
    price: 25,
    unit: "kg",
    stock: 180,
    rating: 4.4,
    location: "Mandya",
    category: "Vegetables",
  },
  {
    id: 8,
    name: "Brinjal (Eggplant)",
    farmer: "Mohan Reddy",
    image:
      "https://images.unsplash.com/photo-1659261200833-ec8761558af7?q=80&w=800",
    price: 38,
    unit: "kg",
    stock: 90,
    rating: 4.6,
    location: "Mysore",
    category: "Vegetables",
  },
  {
    id: 9,
    name: "Beans",
    farmer: "Lakshmi Naik",
    image:
      "https://images.unsplash.com/photo-1607428000821-9b6c6e3d0c4f?q=80&w=800",
    price: 60,
    unit: "kg",
    stock: 85,
    rating: 4.7,
    location: "Chikmagalur",
    category: "Vegetables",
  },
  {
    id: 10,
    name: "Spinach",
    farmer: "Anand Kumar",
    image:
      "https://images.unsplash.com/photo-1576045057995-568f588f82fb?q=80&w=800",
    price: 35,
    unit: "kg",
    stock: 70,
    rating: 4.5,
    location: "Bangalore",
    category: "Vegetables",
  },

  // Fruits
  {
    id: 11,
    name: "Fresh Bananas",
    farmer: "Lakshmi Devi",
    image:
      "https://images.unsplash.com/photo-1603833665858-e61d17a86224?q=80&w=800",
    price: 40,
    unit: "dozen",
    stock: 200,
    rating: 4.7,
    location: "Hassan",
    category: "Fruits",
  },
  {
    id: 12,
    name: "Mangoes (Alphonso)",
    farmer: "Krishna Murthy",
    image:
      "https://images.unsplash.com/photo-1553279768-865429fa0078?q=80&w=800",
    price: 120,
    unit: "kg",
    stock: 150,
    rating: 4.9,
    location: "Raichur",
    category: "Fruits",
  },
  {
    id: 13,
    name: "Pomegranates",
    farmer: "Vijay Patil",
    image:
      "https://images.unsplash.com/photo-1615485500704-8e990f9900f7?q=80&w=800",
    price: 90,
    unit: "kg",
    stock: 80,
    rating: 4.8,
    location: "Bijapur",
    category: "Fruits",
  },
  {
    id: 14,
    name: "Grapes",
    farmer: "Suresh Gowda",
    image:
      "https://images.unsplash.com/photo-1599819177331-6d0b4cd1e8d7?q=80&w=800",
    price: 85,
    unit: "kg",
    stock: 100,
    rating: 4.7,
    location: "Belgaum",
    category: "Fruits",
  },
  {
    id: 15,
    name: "Papayas",
    farmer: "Ramya Devi",
    image:
      "https://images.unsplash.com/photo-1617112848923-cc2234396a8d?q=80&w=800",
    price: 45,
    unit: "kg",
    stock: 120,
    rating: 4.6,
    location: "Tumkur",
    category: "Fruits",
  },
  {
    id: 16,
    name: "Watermelons",
    farmer: "Nagaraj Reddy",
    image:
      "https://images.unsplash.com/photo-1587049352846-4a222e784acc?q=80&w=800",
    price: 20,
    unit: "kg",
    stock: 250,
    rating: 4.5,
    location: "Kolar",
    category: "Fruits",
  },
  {
    id: 17,
    name: "Oranges",
    farmer: "Priya Sharma",
    image:
      "https://images.unsplash.com/photo-1580052614034-c55d20bfee3b?q=80&w=800",
    price: 60,
    unit: "kg",
    stock: 140,
    rating: 4.7,
    location: "Coorg",
    category: "Fruits",
  },
  {
    id: 18,
    name: "Guavas",
    farmer: "Shankar Naik",
    image:
      "https://images.unsplash.com/photo-1536511132770-e5058c7e8c46?q=80&w=800",
    price: 50,
    unit: "kg",
    stock: 95,
    rating: 4.6,
    location: "Ramanagara",
    category: "Fruits",
  },

  // Grains
  {
    id: 19,
    name: "Organic Rice",
    farmer: "Suresh Patil",
    image:
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?q=80&w=800",
    price: 65,
    unit: "kg",
    stock: 500,
    rating: 4.9,
    location: "Mysore",
    category: "Grains",
  },
  {
    id: 20,
    name: "Organic Wheat",
    farmer: "Venkatesh Naik",
    image:
      "https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?q=80&w=800",
    price: 55,
    unit: "kg",
    stock: 400,
    rating: 4.8,
    location: "Mandya",
    category: "Grains",
  },
  {
    id: 21,
    name: "Jowar (Sorghum)",
    farmer: "Basavaraj Gowda",
    image:
      "https://images.unsplash.com/photo-1595855759920-86582396756a?q=80&w=800",
    price: 48,
    unit: "kg",
    stock: 300,
    rating: 4.6,
    location: "Dharwad",
    category: "Grains",
  },
  {
    id: 22,
    name: "Ragi (Finger Millet)",
    farmer: "Manjula Devi",
    image:
      "https://images.unsplash.com/photo-1599909533730-f9d7e4f2e3e3?q=80&w=800",
    price: 52,
    unit: "kg",
    stock: 250,
    rating: 4.7,
    location: "Tumkur",
    category: "Grains",
  },

  // Pulses
  {
    id: 23,
    name: "Toor Dal (Pigeon Pea)",
    farmer: "Ramesh Kumar",
    image:
      "https://images.unsplash.com/photo-1596797038530-2c107229654b?q=80&w=800",
    price: 110,
    unit: "kg",
    stock: 200,
    rating: 4.8,
    location: "Gulbarga",
    category: "Pulses",
  },
  {
    id: 24,
    name: "Moong Dal (Green Gram)",
    farmer: "Savita Patil",
    image:
      "https://images.unsplash.com/photo-1599909533730-f9d7e4f2e3e3?q=80&w=800",
    price: 95,
    unit: "kg",
    stock: 180,
    rating: 4.7,
    location: "Belgaum",
    category: "Pulses",
  },
  {
    id: 25,
    name: "Chana Dal (Bengal Gram)",
    farmer: "Prakash Reddy",
    image:
      "https://images.unsplash.com/photo-1596797038530-2c107229654b?q=80&w=800",
    price: 88,
    unit: "kg",
    stock: 220,
    rating: 4.6,
    location: "Raichur",
    category: "Pulses",
  },

  // Dairy
  {
    id: 26,
    name: "Fresh Cow Milk",
    farmer: "Dairy Farm Co-op",
    image:
      "https://images.unsplash.com/photo-1563636619-e9143da7973b?q=80&w=800",
    price: 55,
    unit: "liter",
    stock: 100,
    rating: 4.9,
    location: "Bangalore",
    category: "Dairy",
  },
  {
    id: 27,
    name: "Buffalo Milk",
    farmer: "Gowri Dairy",
    image:
      "https://images.unsplash.com/photo-1550583724-b2692b85b150?q=80&w=800",
    price: 65,
    unit: "liter",
    stock: 80,
    rating: 4.8,
    location: "Mysore",
    category: "Dairy",
  },
  {
    id: 28,
    name: "Fresh Paneer",
    farmer: "Nandini Dairy",
    image:
      "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?q=80&w=800",
    price: 280,
    unit: "kg",
    stock: 50,
    rating: 4.9,
    location: "Bangalore",
    category: "Dairy",
  },

  // Spices
  {
    id: 29,
    name: "Turmeric Powder",
    farmer: "Spice Farmers Co-op",
    image:
      "https://images.unsplash.com/photo-1615485500704-8e990f9900f7?q=80&w=800",
    price: 180,
    unit: "kg",
    stock: 60,
    rating: 4.8,
    location: "Coorg",
    category: "Spices",
  },
  {
    id: 30,
    name: "Red Chilli Powder",
    farmer: "Guntur Spices",
    image:
      "https://images.unsplash.com/photo-1599909533730-f9d7e4f2e3e3?q=80&w=800",
    price: 220,
    unit: "kg",
    stock: 75,
    rating: 4.7,
    location: "Belgaum",
    category: "Spices",
  },
  {
    id: 31,
    name: "Coriander Seeds",
    farmer: "Rajesh Spices",
    image:
      "https://images.unsplash.com/photo-1596797038530-2c107229654b?q=80&w=800",
    price: 150,
    unit: "kg",
    stock: 90,
    rating: 4.6,
    location: "Raichur",
    category: "Spices",
  },
  {
    id: 32,
    name: "Black Pepper",
    farmer: "Kerala Spice Co-op",
    image:
      "https://images.unsplash.com/photo-1599909533730-f9d7e4f2e3e3?q=80&w=800",
    price: 650,
    unit: "kg",
    stock: 40,
    rating: 4.9,
    location: "Coorg",
    category: "Spices",
  },

  // Leafy Greens
  {
    id: 33,
    name: "Coriander Leaves",
    farmer: "Green Farms",
    image:
      "https://images.unsplash.com/photo-1576045057995-568f588f82fb?q=80&w=800",
    price: 25,
    unit: "kg",
    stock: 60,
    rating: 4.5,
    location: "Bangalore",
    category: "Leafy Greens",
  },
  {
    id: 34,
    name: "Mint Leaves",
    farmer: "Fresh Herbs Co-op",
    image:
      "https://images.unsplash.com/photo-1628556270448-4d4e4148e1b1?q=80&w=800",
    price: 30,
    unit: "kg",
    stock: 50,
    rating: 4.6,
    location: "Mysore",
    category: "Leafy Greens",
  },
  {
    id: 35,
    name: "Curry Leaves",
    farmer: "Aromatic Farms",
    image:
      "https://images.unsplash.com/photo-1576045057995-568f588f82fb?q=80&w=800",
    price: 40,
    unit: "kg",
    stock: 45,
    rating: 4.7,
    location: "Hassan",
    category: "Leafy Greens",
  },
];

export default function MarketplacePage() {
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [quantities, setQuantities] = useState({});
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }

    const savedCart = localStorage.getItem("agri_cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const updateQuantity = (productId, delta) => {
    setQuantities((prev) => ({
      ...prev,
      [productId]: Math.max(1, (prev[productId] || 1) + delta),
    }));
  };

  const addToCart = (product) => {
    const quantity = quantities[product.id] || 1;
    const newCart = [...cart, { ...product, quantity, type: "product" }];
    setCart(newCart);
    localStorage.setItem("agri_cart", JSON.stringify(newCart));
    setQuantities((prev) => ({ ...prev, [product.id]: 1 }));
  };

  const filteredProducts = products.filter((product) => {
    const matchesCategory =
      selectedCategory === "All Categories" ||
      product.category === selectedCategory;
    const matchesSearch =
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.farmer.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              Farm Direct Marketplace
            </h1>
            <a
              href="/cart"
              className="p-2 hover:bg-gray-100 rounded-full transition-colors relative"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-green-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </a>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-12">
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              Fresh from Farm to Table
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Buy directly from farmers and support local agriculture
            </p>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
              >
                <option>All Categories</option>
                <option>Vegetables</option>
                <option>Fruits</option>
                <option>Grains</option>
                <option>Pulses</option>
                <option>Dairy</option>
                <option>Spices</option>
                <option>Leafy Greens</option>
              </select>
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>All Locations</option>
                <option>Bangalore Rural</option>
                <option>Mysore</option>
                <option>Hassan</option>
                <option>Mandya</option>
                <option>Tumkur</option>
              </select>
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>Sort by: Featured</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Rating</option>
              </select>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search products..."
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
              />
            </div>
          </div>

          {/* Product Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <motion.div
                key={product.id}
                whileHover={{ y: -5 }}
                transition={{ duration: 0.3 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-all"
              >
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-white px-3 py-1 rounded-full flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    <span className="text-sm font-semibold text-gray-900">
                      {product.rating}
                    </span>
                  </div>
                  <div className="absolute top-3 left-3 bg-green-600 text-white px-3 py-1 rounded-full text-xs font-medium">
                    {product.category}
                  </div>
                </div>

                <div className="p-6">
                  <div className="mb-4">
                    <h3 className="text-xl font-semibold text-gray-900 mb-1">
                      {product.name}
                    </h3>
                    <p className="text-sm text-gray-600">by {product.farmer}</p>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex items-center gap-2 text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span className="text-sm">{product.location}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">In Stock</span>
                      <span className="text-sm font-semibold text-green-700">
                        {product.stock} {product.unit}
                      </span>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 pt-4 mb-4">
                    <div className="flex items-center justify-between mb-4">
                      <span className="text-2xl font-bold text-gray-900">
                        ₹{product.price}
                      </span>
                      <span className="text-sm text-gray-600">
                        per {product.unit}
                      </span>
                    </div>

                    <div className="flex items-center gap-3 mb-4">
                      <button
                        onClick={() => updateQuantity(product.id, -1)}
                        className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <Minus className="w-4 h-4 text-gray-700" />
                      </button>
                      <span className="text-lg font-semibold text-gray-900 min-w-[40px] text-center">
                        {quantities[product.id] || 1}
                      </span>
                      <button
                        onClick={() => updateQuantity(product.id, 1)}
                        className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <Plus className="w-4 h-4 text-gray-700" />
                      </button>
                    </div>
                  </div>

                  <button
                    onClick={() => addToCart(product)}
                    className="w-full px-4 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="w-5 h-5" />
                    Add to Cart
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
              <p className="text-gray-600">
                No products found matching your criteria
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
