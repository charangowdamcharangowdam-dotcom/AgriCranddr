"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ArrowLeft, Trash2, Plus, Minus, CreditCard } from "lucide-react";

export default function CartPage() {
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [showPayment, setShowPayment] = useState(false);

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }

    const savedCart = localStorage.getItem("agri_cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const updateQuantity = (index, delta) => {
    const newCart = [...cart];
    newCart[index].quantity = Math.max(1, newCart[index].quantity + delta);
    setCart(newCart);
    localStorage.setItem("agri_cart", JSON.stringify(newCart));
  };

  const removeItem = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    localStorage.setItem("agri_cart", JSON.stringify(newCart));
  };

  const calculateSubtotal = () => {
    return cart.reduce((sum, item) => {
      const price = item.pricePerDay || item.price || 0;
      return sum + price * item.quantity;
    }, 0);
  };

  const deliveryCharge = 50;
  const subtotal = calculateSubtotal();
  const total = subtotal + deliveryCharge;

  const handleCheckout = () => {
    setShowPayment(true);
  };

  const handlePayment = (method) => {
    alert(`Payment initiated via ${method}. This is a demo payment system.`);
    setTimeout(() => {
      alert("Payment successful! Order placed.");
      setCart([]);
      localStorage.setItem("agri_cart", JSON.stringify([]));
      setShowPayment(false);
      window.location.href = "/home";
    }, 2000);
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              Shopping Cart
            </h1>
          </div>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          {cart.length === 0 ? (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
              <h2 className="text-2xl font-light text-gray-900 mb-3">
                Your cart is empty
              </h2>
              <p className="text-gray-600 mb-6">
                Add some products or services to get started
              </p>
              <a
                href="/home"
                className="inline-block px-8 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
              >
                Continue Shopping
              </a>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {cart.map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className="bg-white rounded-xl shadow-sm border border-gray-200 p-6"
                  >
                    <div className="flex gap-6">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-24 h-24 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">
                              {item.name}
                            </h3>
                            <p className="text-sm text-gray-600">
                              {item.brand || item.farmer || item.location}
                            </p>
                          </div>
                          <button
                            onClick={() => removeItem(index)}
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5 text-red-600" />
                          </button>
                        </div>

                        <div className="flex items-center justify-between mt-4">
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() => updateQuantity(index, -1)}
                              className="p-1 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              <Minus className="w-4 h-4 text-gray-700" />
                            </button>
                            <span className="text-lg font-semibold text-gray-900 min-w-[40px] text-center">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(index, 1)}
                              className="p-1 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              <Plus className="w-4 h-4 text-gray-700" />
                            </button>
                          </div>
                          <div className="text-right">
                            <p className="text-sm text-gray-600">
                              ₹{item.pricePerDay || item.price} ×{" "}
                              {item.quantity}
                            </p>
                            <p className="text-xl font-bold text-gray-900">
                              ₹
                              {(item.pricePerDay || item.price) * item.quantity}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 sticky top-24">
                  <h2 className="text-xl font-semibold text-gray-900 mb-6">
                    Order Summary
                  </h2>

                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between text-gray-700">
                      <span>Subtotal</span>
                      <span className="font-semibold">₹{subtotal}</span>
                    </div>
                    <div className="flex items-center justify-between text-gray-700">
                      <span>Delivery Charge</span>
                      <span className="font-semibold">₹{deliveryCharge}</span>
                    </div>
                    <div className="border-t border-gray-200 pt-3">
                      <div className="flex items-center justify-between text-gray-900">
                        <span className="text-lg font-semibold">Total</span>
                        <span className="text-2xl font-bold">₹{total}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={handleCheckout}
                    className="w-full bg-black text-white py-4 rounded-lg font-medium hover:bg-gray-800 transition-all duration-300 hover:shadow-lg flex items-center justify-center gap-2"
                  >
                    <CreditCard className="w-5 h-5" />
                    Proceed to Checkout
                  </button>
                </div>
              </div>
            </div>
          )}
        </motion.div>
      </div>

      {/* Payment Modal */}
      {showPayment && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-8"
          >
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">
              Choose Payment Method
            </h2>

            <div className="space-y-3 mb-6">
              <button
                onClick={() => handlePayment("UPI")}
                className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-left"
              >
                <div className="font-semibold text-gray-900">UPI</div>
                <div className="text-sm text-gray-600">
                  Pay using Google Pay, PhonePe, Paytm
                </div>
              </button>

              <button
                onClick={() => handlePayment("Card")}
                className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-left"
              >
                <div className="font-semibold text-gray-900">
                  Credit/Debit Card
                </div>
                <div className="text-sm text-gray-600">
                  Visa, Mastercard, RuPay
                </div>
              </button>

              <button
                onClick={() => handlePayment("Net Banking")}
                className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-left"
              >
                <div className="font-semibold text-gray-900">Net Banking</div>
                <div className="text-sm text-gray-600">
                  All major banks supported
                </div>
              </button>

              <button
                onClick={() => handlePayment("Wallet")}
                className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all text-left"
              >
                <div className="font-semibold text-gray-900">Wallets</div>
                <div className="text-sm text-gray-600">
                  Paytm, PhonePe, Amazon Pay
                </div>
              </button>
            </div>

            <button
              onClick={() => setShowPayment(false)}
              className="w-full py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium"
            >
              Cancel
            </button>
          </motion.div>
        </div>
      )}
    </div>
  );
}
