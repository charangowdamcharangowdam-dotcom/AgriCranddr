"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Cloud,
  Droplets,
  Wind,
  Thermometer,
  Sun,
  CloudRain,
  Leaf,
  AlertTriangle,
} from "lucide-react";

const cityWeatherData = {
  "Bangalore, Karnataka": {
    temp: 28,
    feelsLike: 30,
    humidity: 65,
    rainfall: 12,
    wind: 8,
    pressure: 1013,
    visibility: 10,
    uvIndex: 7,
    condition: "Partly Cloudy",
    icon: "cloud",
  },
  "Mumbai, Maharashtra": {
    temp: 32,
    feelsLike: 36,
    humidity: 75,
    rainfall: 5,
    wind: 12,
    pressure: 1010,
    visibility: 8,
    uvIndex: 9,
    condition: "Humid",
    icon: "cloud",
  },
  "Delhi, NCR": {
    temp: 35,
    feelsLike: 38,
    humidity: 45,
    rainfall: 2,
    wind: 10,
    pressure: 1008,
    visibility: 6,
    uvIndex: 10,
    condition: "Hot & Dry",
    icon: "sun",
  },
  "Chennai, Tamil Nadu": {
    temp: 34,
    feelsLike: 37,
    humidity: 80,
    rainfall: 8,
    wind: 15,
    pressure: 1009,
    visibility: 9,
    uvIndex: 9,
    condition: "Hot & Humid",
    icon: "sun",
  },
  "Kolkata, West Bengal": {
    temp: 33,
    feelsLike: 36,
    humidity: 78,
    rainfall: 15,
    wind: 11,
    pressure: 1011,
    visibility: 7,
    uvIndex: 8,
    condition: "Humid",
    icon: "cloud",
  },
  "Hyderabad, Telangana": {
    temp: 31,
    feelsLike: 34,
    humidity: 60,
    rainfall: 10,
    wind: 9,
    pressure: 1012,
    visibility: 10,
    uvIndex: 8,
    condition: "Partly Cloudy",
    icon: "cloud",
  },
  "Pune, Maharashtra": {
    temp: 29,
    feelsLike: 31,
    humidity: 55,
    rainfall: 8,
    wind: 7,
    pressure: 1014,
    visibility: 12,
    uvIndex: 7,
    condition: "Pleasant",
    icon: "cloud",
  },
  "Ahmedabad, Gujarat": {
    temp: 36,
    feelsLike: 39,
    humidity: 40,
    rainfall: 1,
    wind: 13,
    pressure: 1007,
    visibility: 8,
    uvIndex: 10,
    condition: "Hot",
    icon: "sun",
  },
  "Jaipur, Rajasthan": {
    temp: 37,
    feelsLike: 40,
    humidity: 35,
    rainfall: 0,
    wind: 14,
    pressure: 1006,
    visibility: 10,
    uvIndex: 11,
    condition: "Very Hot",
    icon: "sun",
  },
  "Lucknow, Uttar Pradesh": {
    temp: 34,
    feelsLike: 37,
    humidity: 50,
    rainfall: 5,
    wind: 8,
    pressure: 1009,
    visibility: 9,
    uvIndex: 9,
    condition: "Warm",
    icon: "sun",
  },
  "Mysore, Karnataka": {
    temp: 27,
    feelsLike: 29,
    humidity: 68,
    rainfall: 14,
    wind: 7,
    pressure: 1014,
    visibility: 11,
    uvIndex: 6,
    condition: "Pleasant",
    icon: "cloud",
  },
  "Coimbatore, Tamil Nadu": {
    temp: 30,
    feelsLike: 33,
    humidity: 65,
    rainfall: 10,
    wind: 9,
    pressure: 1012,
    visibility: 10,
    uvIndex: 8,
    condition: "Moderate",
    icon: "cloud",
  },
  "Kochi, Kerala": {
    temp: 29,
    feelsLike: 32,
    humidity: 85,
    rainfall: 20,
    wind: 10,
    pressure: 1011,
    visibility: 8,
    uvIndex: 7,
    condition: "Rainy",
    icon: "rain",
  },
  "Visakhapatnam, Andhra Pradesh": {
    temp: 31,
    feelsLike: 34,
    humidity: 72,
    rainfall: 12,
    wind: 11,
    pressure: 1010,
    visibility: 9,
    uvIndex: 8,
    condition: "Coastal",
    icon: "cloud",
  },
  "Bhopal, Madhya Pradesh": {
    temp: 33,
    feelsLike: 35,
    humidity: 48,
    rainfall: 6,
    wind: 8,
    pressure: 1010,
    visibility: 10,
    uvIndex: 9,
    condition: "Warm",
    icon: "sun",
  },
};

const generateForecast = (baseTemp) => {
  return [
    {
      day: "Today",
      high: baseTemp + 2,
      low: baseTemp - 6,
      condition: "Partly Cloudy",
      rain: 20,
      icon: "cloud",
    },
    {
      day: "Tomorrow",
      high: baseTemp + 1,
      low: baseTemp - 7,
      condition: "Light Rain",
      rain: 60,
      icon: "rain",
    },
    {
      day: "Wednesday",
      high: baseTemp - 1,
      low: baseTemp - 8,
      condition: "Rainy",
      rain: 80,
      icon: "rain",
    },
    {
      day: "Thursday",
      high: baseTemp,
      low: baseTemp - 7,
      condition: "Cloudy",
      rain: 40,
      icon: "cloud",
    },
    {
      day: "Friday",
      high: baseTemp + 3,
      low: baseTemp - 5,
      condition: "Sunny",
      rain: 10,
      icon: "sun",
    },
    {
      day: "Saturday",
      high: baseTemp + 4,
      low: baseTemp - 4,
      condition: "Sunny",
      rain: 5,
      icon: "sun",
    },
    {
      day: "Sunday",
      high: baseTemp + 2,
      low: baseTemp - 6,
      condition: "Partly Cloudy",
      rain: 30,
      icon: "cloud",
    },
  ];
};

export default function WeatherPage() {
  const [user, setUser] = useState(null);
  const [location, setLocation] = useState("Bangalore, Karnataka");
  const [currentWeather, setCurrentWeather] = useState(null);
  const [forecast, setForecast] = useState([]);

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }
  }, []);

  useEffect(() => {
    // Update weather based on location
    const weatherData =
      cityWeatherData[location] || cityWeatherData["Bangalore, Karnataka"];
    setCurrentWeather(weatherData);
    setForecast(generateForecast(weatherData.temp));
  }, [location]);

  const getWeatherIcon = (icon) => {
    switch (icon) {
      case "sun":
        return <Sun className="w-12 h-12 text-yellow-500" />;
      case "rain":
        return <CloudRain className="w-12 h-12 text-blue-500" />;
      default:
        return <Cloud className="w-12 h-12 text-gray-500" />;
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              Weather & Forecast
            </h1>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-8">
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              Weather Forecast
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Real-time weather updates and agricultural recommendations
            </p>
          </div>

          {/* Location Selector */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4 mb-8">
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
            >
              {Object.keys(cityWeatherData).map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
          </div>

          {/* Current Weather */}
          {currentWeather && (
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg p-8 mb-8 text-white">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-light mb-2">Current Weather</h2>
                  <p className="text-blue-100">{location}</p>
                </div>
                <Cloud className="w-20 h-20 text-white/80" />
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <div>
                  <p className="text-blue-100 text-sm mb-1">Temperature</p>
                  <p className="text-4xl font-bold">{currentWeather.temp}°C</p>
                  <p className="text-blue-100 text-sm mt-1">
                    Feels like {currentWeather.feelsLike}°C
                  </p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">Humidity</p>
                  <p className="text-4xl font-bold">
                    {currentWeather.humidity}%
                  </p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">Wind Speed</p>
                  <p className="text-4xl font-bold">{currentWeather.wind}</p>
                  <p className="text-blue-100 text-sm mt-1">km/h</p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">Rainfall</p>
                  <p className="text-4xl font-bold">
                    {currentWeather.rainfall}
                  </p>
                  <p className="text-blue-100 text-sm mt-1">mm</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-6 pt-6 border-t border-blue-400">
                <div>
                  <p className="text-blue-100 text-sm mb-1">Pressure</p>
                  <p className="text-xl font-semibold">
                    {currentWeather.pressure} hPa
                  </p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">Visibility</p>
                  <p className="text-xl font-semibold">
                    {currentWeather.visibility} km
                  </p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">UV Index</p>
                  <p className="text-xl font-semibold">
                    {currentWeather.uvIndex}
                  </p>
                </div>
                <div>
                  <p className="text-blue-100 text-sm mb-1">Condition</p>
                  <p className="text-xl font-semibold">
                    {currentWeather.condition}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* AI Recommendations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-3 bg-green-100 rounded-lg">
                  <Leaf className="w-6 h-6 text-green-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">
                    Irrigation Advice
                  </h3>
                  <p className="text-gray-700">
                    Light rainfall expected tomorrow. Reduce irrigation today to
                    prevent waterlogging. Resume normal irrigation after 48
                    hours.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Droplets className="w-6 h-6 text-blue-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">
                    Crop Recommendation
                  </h3>
                  <p className="text-gray-700">
                    Current conditions are ideal for tomato and chilli
                    cultivation. Consider planting within the next 3-5 days.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-3 bg-orange-100 rounded-lg">
                  <AlertTriangle className="w-6 h-6 text-orange-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">
                    Weather Alert
                  </h3>
                  <p className="text-gray-700">
                    Moderate rainfall expected on Wednesday. Ensure proper
                    drainage in fields to prevent crop damage.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-start gap-3 mb-4">
                <div className="p-3 bg-yellow-100 rounded-lg">
                  <Sun className="w-6 h-6 text-yellow-700" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-1">
                    Pest Management
                  </h3>
                  <p className="text-gray-700">
                    High humidity levels may increase pest activity. Monitor
                    crops closely and apply preventive measures.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* 7-Day Forecast */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">
              7-Day Forecast
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
              {forecast.map((day, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl p-4 text-center hover:shadow-md transition-all"
                >
                  <p className="font-semibold text-gray-900 mb-3">{day.day}</p>
                  <div className="flex justify-center mb-3">
                    {getWeatherIcon(day.icon)}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{day.condition}</p>
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <span className="text-lg font-bold text-gray-900">
                      {day.high}°
                    </span>
                    <span className="text-sm text-gray-500">{day.low}°</span>
                  </div>
                  <div className="flex items-center justify-center gap-1 text-blue-600">
                    <Droplets className="w-4 h-4" />
                    <span className="text-sm font-medium">{day.rain}%</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
