"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { ArrowLeft, Mic, Volume2, Languages } from "lucide-react";

export default function SathiPage() {
  const [user, setUser] = useState(null);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }
  }, []);

  const startListening = () => {
    setIsListening(true);
    setTranscript("");
    setResponse("");

    // Simulate voice recognition
    setTimeout(() => {
      const sampleQueries = [
        "What is the weather forecast for tomorrow?",
        "How do I treat early blight in tomatoes?",
        "What fertilizer should I use for rice?",
        "When is the best time to plant wheat?",
      ];
      const randomQuery =
        sampleQueries[Math.floor(Math.random() * sampleQueries.length)];
      setTranscript(randomQuery);
      setIsListening(false);

      // Simulate AI response
      setTimeout(() => {
        const responses = {
          "What is the weather forecast for tomorrow?":
            "Tomorrow's forecast shows partly cloudy skies with a high of 29°C and low of 22°C. There is a 40% chance of light rainfall in the evening. It would be a good day for irrigation activities.",
          "How do I treat early blight in tomatoes?":
            "For early blight in tomatoes, I recommend: 1) Remove and destroy infected leaves immediately. 2) Apply Mancozeb 75% WP fungicide. 3) Ensure proper plant spacing for air circulation. 4) Use drip irrigation instead of overhead watering.",
          "What fertilizer should I use for rice?":
            "For rice cultivation, use NPK fertilizer in a 4:2:1 ratio. Apply urea at 120 kg/ha, single super phosphate at 60 kg/ha, and muriate of potash at 30 kg/ha. Split the application into three stages: basal, tillering, and panicle initiation.",
          "When is the best time to plant wheat?":
            "The best time to plant wheat in Karnataka is from mid-October to mid-November. The ideal temperature for germination is 20-25°C. Ensure soil moisture is adequate before sowing.",
        };
        setResponse(
          responses[randomQuery] ||
            "I can help you with farming advice, weather information, and crop disease management. Please ask me anything!",
        );
      }, 1500);
    }, 3000);
  };

  const speakResponse = () => {
    if ("speechSynthesis" in window && response) {
      const utterance = new SpeechSynthesisUtterance(response);
      utterance.lang =
        language === "en" ? "en-IN" : language === "hi" ? "hi-IN" : "kn-IN";
      window.speechSynthesis.speak(utterance);
    }
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              Cranddr Sathi - AI Voice Assistant
            </h1>
          </div>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-100 to-blue-200 rounded-full mb-4">
              <Mic className="w-10 h-10 text-blue-700" />
            </div>
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              Your AI Farming Assistant
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Ask me anything about farming, weather, or crop management
            </p>
          </div>

          {/* Language Selector */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
            <div className="flex items-center gap-3 mb-4">
              <Languages className="w-5 h-5 text-gray-700" />
              <h2 className="text-lg font-semibold text-gray-900">
                Select Language
              </h2>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { code: "en", name: "English" },
                { code: "kn", name: "ಕನ್ನಡ (Kannada)" },
                { code: "hi", name: "हिंदी (Hindi)" },
                { code: "ta", name: "தமிழ் (Tamil)" },
                { code: "te", name: "తెలుగు (Telugu)" },
                { code: "ml", name: "മലയാളം (Malayalam)" },
              ].map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code)}
                  className={`px-4 py-3 rounded-lg border-2 transition-all font-medium ${
                    language === lang.code
                      ? "border-green-500 bg-green-50 text-green-700"
                      : "border-gray-200 hover:border-gray-300 text-gray-700"
                  }`}
                >
                  {lang.name}
                </button>
              ))}
            </div>
          </div>

          {/* Voice Interface */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12">
            <div className="flex flex-col items-center">
              <button
                onClick={startListening}
                disabled={isListening}
                className={`w-32 h-32 rounded-full flex items-center justify-center transition-all duration-300 ${
                  isListening
                    ? "bg-red-500 hover:bg-red-600 scale-110"
                    : "bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 hover:scale-105"
                } shadow-lg hover:shadow-xl disabled:opacity-50`}
              >
                <Mic className="w-16 h-16 text-white" />
              </button>

              <p className="mt-6 text-lg font-medium text-gray-900">
                {isListening ? "Listening..." : "Tap to speak"}
              </p>
              <p className="text-sm text-gray-600 mt-2">
                {isListening
                  ? "Speak your question clearly"
                  : "Ask about weather, crops, or farming advice"}
              </p>

              {transcript && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-8 w-full"
                >
                  <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
                    <h3 className="font-semibold text-gray-900 mb-2 flex items-center gap-2">
                      <Mic className="w-5 h-5 text-blue-600" />
                      You asked:
                    </h3>
                    <p className="text-gray-700">{transcript}</p>
                  </div>
                </motion.div>
              )}

              {response && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 w-full"
                >
                  <div className="bg-green-50 border border-green-200 rounded-xl p-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                        <Volume2 className="w-5 h-5 text-green-600" />
                        Cranddr Sathi says:
                      </h3>
                      <button
                        onClick={speakResponse}
                        className="p-2 hover:bg-green-100 rounded-lg transition-colors"
                        title="Listen to response"
                      >
                        <Volume2 className="w-5 h-5 text-green-700" />
                      </button>
                    </div>
                    <p className="text-gray-700 leading-relaxed">{response}</p>
                  </div>
                </motion.div>
              )}
            </div>
          </div>

          {/* Quick Questions */}
          <div className="mt-8 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="font-semibold text-gray-900 mb-4">
              Quick Questions
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {[
                "What is today's weather?",
                "How to prevent crop diseases?",
                "Best fertilizer for vegetables?",
                "When to harvest rice?",
              ].map((question, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setTranscript(question);
                    setTimeout(() => {
                      setResponse(
                        "This is a sample response. In production, this would connect to a real AI service.",
                      );
                    }, 1000);
                  }}
                  className="px-4 py-3 text-left border border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all text-gray-700"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
