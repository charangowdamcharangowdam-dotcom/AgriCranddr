"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  MapPin,
  Fuel,
  User as UserIcon,
  ShoppingCart,
  Star,
  Map as MapIcon,
  Grid3x3,
} from "lucide-react";
import { APIProvider, Map, Marker } from "@vis.gl/react-google-maps";

const tractors = [
  {
    id: 1,
    name: "Mahindra 575 DI",
    brand: "Mahindra",
    image:
      "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=800",
    hp: "47 HP",
    pricePerHour: 450,
    pricePerDay: 3500,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.8,
    location: "Bangalore Rural",
    lat: 12.9716,
    lng: 77.5946,
  },
  {
    id: 2,
    name: "John Deere 5050 D",
    brand: "John Deere",
    image:
      "https://images.unsplash.com/photo-1589923188900-85dae523342b?q=80&w=800",
    hp: "50 HP",
    pricePerHour: 550,
    pricePerDay: 4200,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.9,
    location: "Mysore",
    lat: 12.2958,
    lng: 76.6394,
  },
  {
    id: 3,
    name: "Swaraj 744 FE",
    brand: "Swaraj",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?q=80&w=800",
    hp: "48 HP",
    pricePerHour: 400,
    pricePerDay: 3200,
    available: true,
    fuel: "Diesel",
    driverIncluded: false,
    rating: 4.6,
    location: "Hassan",
    lat: 13.0033,
    lng: 76.1004,
  },
  {
    id: 4,
    name: "Sonalika DI 745 III",
    brand: "Sonalika",
    image:
      "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=800",
    hp: "45 HP",
    pricePerHour: 380,
    pricePerDay: 3000,
    available: false,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.5,
    location: "Tumkur",
    lat: 13.3392,
    lng: 77.1006,
  },
  {
    id: 5,
    name: "Mahindra Arjun 605",
    brand: "Mahindra",
    image:
      "https://images.unsplash.com/photo-1589923188900-85dae523342b?q=80&w=800",
    hp: "63 HP",
    pricePerHour: 650,
    pricePerDay: 5000,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.9,
    location: "Mandya",
    lat: 12.5244,
    lng: 76.8958,
  },
  {
    id: 6,
    name: "Mini Tractor MT-250",
    brand: "Farmtrac",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?q=80&w=800",
    hp: "25 HP",
    pricePerHour: 250,
    pricePerDay: 2000,
    available: true,
    fuel: "Diesel",
    driverIncluded: false,
    rating: 4.3,
    location: "Kolar",
    lat: 13.1367,
    lng: 78.1297,
  },
  {
    id: 7,
    name: "New Holland 3630 TX",
    brand: "New Holland",
    image:
      "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=800",
    hp: "55 HP",
    pricePerHour: 500,
    pricePerDay: 3800,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.7,
    location: "Belgaum",
    lat: 15.8497,
    lng: 74.4977,
  },
  {
    id: 8,
    name: "Massey Ferguson 241 DI",
    brand: "Massey Ferguson",
    image:
      "https://images.unsplash.com/photo-1589923188900-85dae523342b?q=80&w=800",
    hp: "42 HP",
    pricePerHour: 420,
    pricePerDay: 3300,
    available: true,
    fuel: "Diesel",
    driverIncluded: false,
    rating: 4.6,
    location: "Shimoga",
    lat: 13.9299,
    lng: 75.5681,
  },
  {
    id: 9,
    name: "Kubota MU5502",
    brand: "Kubota",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?q=80&w=800",
    hp: "55 HP",
    pricePerHour: 580,
    pricePerDay: 4500,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.8,
    location: "Chikmagalur",
    lat: 13.3161,
    lng: 75.772,
  },
  {
    id: 10,
    name: "Eicher 380",
    brand: "Eicher",
    image:
      "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=800",
    hp: "38 HP",
    pricePerHour: 360,
    pricePerDay: 2800,
    available: true,
    fuel: "Diesel",
    driverIncluded: false,
    rating: 4.4,
    location: "Raichur",
    lat: 16.212,
    lng: 77.3439,
  },
  {
    id: 11,
    name: "Mahindra 265 DI",
    brand: "Mahindra",
    image:
      "https://images.unsplash.com/photo-1589923188900-85dae523342b?q=80&w=800",
    hp: "31 HP",
    pricePerHour: 320,
    pricePerDay: 2500,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.5,
    location: "Dharwad",
    lat: 15.4589,
    lng: 75.0078,
  },
  {
    id: 12,
    name: "John Deere 5310",
    brand: "John Deere",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?q=80&w=800",
    hp: "55 HP",
    pricePerHour: 600,
    pricePerDay: 4600,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.9,
    location: "Gulbarga",
    lat: 17.3297,
    lng: 76.8343,
  },
  {
    id: 13,
    name: "Swaraj 855 FE",
    brand: "Swaraj",
    image:
      "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?q=80&w=800",
    hp: "60 HP",
    pricePerHour: 520,
    pricePerDay: 4000,
    available: true,
    fuel: "Diesel",
    driverIncluded: false,
    rating: 4.7,
    location: "Bijapur",
    lat: 16.8302,
    lng: 75.71,
  },
  {
    id: 14,
    name: "Sonalika RX 60",
    brand: "Sonalika",
    image:
      "https://images.unsplash.com/photo-1589923188900-85dae523342b?q=80&w=800",
    hp: "60 HP",
    pricePerHour: 480,
    pricePerDay: 3700,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.6,
    location: "Davangere",
    lat: 14.4644,
    lng: 75.9218,
  },
  {
    id: 15,
    name: "New Holland 3037 TX",
    brand: "New Holland",
    image:
      "https://images.unsplash.com/photo-1592838064575-70ed626d3a0e?q=80&w=800",
    hp: "50 HP",
    pricePerHour: 470,
    pricePerDay: 3600,
    available: true,
    fuel: "Diesel",
    driverIncluded: true,
    rating: 4.7,
    location: "Bellary",
    lat: 15.1394,
    lng: 76.9214,
  },
];

export default function AgriRidePage() {
  const [user, setUser] = useState(null);
  const [cart, setCart] = useState([]);
  const [viewMode, setViewMode] = useState("grid");

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }

    const savedCart = localStorage.getItem("agri_cart");
    if (savedCart) {
      setCart(JSON.parse(savedCart));
    }
  }, []);

  const addToCart = (tractor) => {
    const newCart = [...cart, { ...tractor, rentalType: "day", quantity: 1 }];
    setCart(newCart);
    localStorage.setItem("agri_cart", JSON.stringify(newCart));
  };

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              AgriRide - Tractor Rental
            </h1>
            <a
              href="/cart"
              className="p-2 hover:bg-gray-100 rounded-full transition-colors relative"
            >
              <ShoppingCart className="w-5 h-5 text-gray-700" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-green-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                  {cart.length}
                </span>
              )}
            </a>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-12">
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              Rent Premium Tractors
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Choose from verified tractors and equipment near you
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${viewMode === "grid" ? "bg-black text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}
                >
                  <Grid3x3 className="w-5 h-5" />
                  Grid View
                </button>
                <button
                  onClick={() => setViewMode("map")}
                  className={`px-4 py-2 rounded-lg flex items-center gap-2 transition-colors ${viewMode === "map" ? "bg-black text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`}
                >
                  <MapIcon className="w-5 h-5" />
                  Map View
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>All Brands</option>
                <option>Mahindra</option>
                <option>John Deere</option>
                <option>Swaraj</option>
                <option>Sonalika</option>
                <option>New Holland</option>
                <option>Massey Ferguson</option>
                <option>Kubota</option>
                <option>Eicher</option>
              </select>
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>All HP Range</option>
                <option>Below 30 HP</option>
                <option>30-50 HP</option>
                <option>Above 50 HP</option>
              </select>
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>All Locations</option>
                <option>Bangalore Rural</option>
                <option>Mysore</option>
                <option>Hassan</option>
              </select>
              <select className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white">
                <option>Available Only</option>
                <option>All Tractors</option>
              </select>
            </div>
          </div>

          {viewMode === "map" && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
              <APIProvider
                apiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || ""}
              >
                <div className="h-[600px]">
                  <Map
                    defaultCenter={{ lat: 13.0827, lng: 77.5877 }}
                    defaultZoom={8}
                    mapId="agriride-map"
                  >
                    {tractors
                      .filter((t) => t.available)
                      .map((tractor) => (
                        <Marker
                          key={tractor.id}
                          position={{ lat: tractor.lat, lng: tractor.lng }}
                          title={`${tractor.name} - ₹${tractor.pricePerDay}/day`}
                        />
                      ))}
                  </Map>
                </div>
              </APIProvider>
              <div className="p-6 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  <span className="font-semibold text-gray-900">
                    {tractors.filter((t) => t.available).length}
                  </span>{" "}
                  tractors available near you
                </p>
              </div>
            </div>
          )}

          {viewMode === "grid" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tractors.map((tractor) => (
                <motion.div
                  key={tractor.id}
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.3 }}
                  className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-lg transition-all"
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={tractor.image}
                      alt={tractor.name}
                      className="w-full h-full object-cover"
                    />
                    {!tractor.available && (
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                        <span className="bg-red-500 text-white px-4 py-2 rounded-full font-medium">
                          Not Available
                        </span>
                      </div>
                    )}
                    <div className="absolute top-3 right-3 bg-white px-3 py-1 rounded-full flex items-center gap-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      <span className="text-sm font-semibold text-gray-900">
                        {tractor.rating}
                      </span>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="mb-4">
                      <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                        {tractor.brand}
                      </span>
                      <h3 className="text-xl font-semibold text-gray-900 mt-1">
                        {tractor.name}
                      </h3>
                    </div>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2 text-gray-600">
                        <Fuel className="w-4 h-4" />
                        <span className="text-sm">
                          {tractor.hp} • {tractor.fuel}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <MapPin className="w-4 h-4" />
                        <span className="text-sm">{tractor.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <UserIcon className="w-4 h-4" />
                        <span className="text-sm">
                          {tractor.driverIncluded
                            ? "Driver Included"
                            : "Self Drive"}
                        </span>
                      </div>
                    </div>

                    <div className="border-t border-gray-200 pt-4 mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">Per Hour</span>
                        <span className="text-lg font-semibold text-gray-900">
                          ₹{tractor.pricePerHour}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Per Day</span>
                        <span className="text-lg font-semibold text-green-700">
                          ₹{tractor.pricePerDay}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <a
                        href={`/agriride/${tractor.id}`}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-medium text-center"
                      >
                        View Details
                      </a>
                      <button
                        onClick={() => addToCart(tractor)}
                        disabled={!tractor.available}
                        className="px-4 py-2 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Add to Cart
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
