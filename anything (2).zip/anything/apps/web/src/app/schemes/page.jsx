"use client";

import { useState, useEffect } from "react";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Search,
  ExternalLink,
  CheckCircle,
  FileText,
} from "lucide-react";

const schemes = [
  {
    id: 1,
    name: "PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)",
    category: "Financial Assistance",
    description:
      "Direct income support of ₹6,000 per year to all farmer families in three equal installments",
    eligibility: "All landholding farmer families",
    benefits: "₹6,000 per year in 3 installments",
    link: "https://pmkisan.gov.in/",
    state: "Central",
  },
  {
    id: 2,
    name: "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
    category: "Insurance",
    description:
      "Crop insurance scheme providing financial support to farmers in case of crop failure",
    eligibility: "All farmers growing notified crops",
    benefits: "Comprehensive risk coverage against crop loss",
    link: "https://pmfby.gov.in/",
    state: "Central",
  },
  {
    id: 3,
    name: "Kisan Credit Card (KCC)",
    category: "Credit",
    description:
      "Provides adequate and timely credit support for agriculture and allied activities",
    eligibility: "Farmers, tenant farmers, sharecroppers",
    benefits: "Easy access to credit at subsidized interest rates",
    link: "https://www.india.gov.in/spotlight/kisan-credit-card-kcc",
    state: "Central",
  },
  {
    id: 4,
    name: "Soil Health Card Scheme",
    category: "Soil Management",
    description:
      "Provides soil health cards to farmers with recommendations on nutrient management",
    eligibility: "All farmers",
    benefits: "Free soil testing and nutrient recommendations",
    link: "https://soilhealth.dac.gov.in/",
    state: "Central",
  },
  {
    id: 5,
    name: "Raitha Shakti (Karnataka)",
    category: "State Scheme",
    description:
      "Karnataka state scheme for farmer welfare and agricultural development",
    eligibility: "Farmers in Karnataka",
    benefits: "Various agricultural subsidies and support",
    link: "https://raitamitra.karnataka.gov.in/",
    state: "Karnataka",
  },
  {
    id: 6,
    name: "National Agriculture Market (e-NAM)",
    category: "Marketing",
    description: "Online trading platform for agricultural commodities",
    eligibility: "All farmers and traders",
    benefits: "Better price discovery and transparent trading",
    link: "https://www.enam.gov.in/",
    state: "Central",
  },
];

export default function SchemesPage() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  useEffect(() => {
    const userData = localStorage.getItem("agri_user");
    if (!userData) {
      window.location.href = "/auth";
    } else {
      setUser(JSON.parse(userData));
    }
  }, []);

  const categories = [
    "All",
    "Financial Assistance",
    "Insurance",
    "Credit",
    "Soil Management",
    "Marketing",
    "State Scheme",
  ];

  const filteredSchemes = schemes.filter((scheme) => {
    const matchesSearch =
      scheme.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      scheme.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory =
      selectedCategory === "All" || scheme.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  if (!user) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-green-50/30 font-inter">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50 backdrop-blur-lg bg-white/95">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <a
                href="/home"
                className="p-2 hover:bg-gray-100 rounded-full transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-700" />
              </a>
              <div className="flex items-center gap-0">
                <div className="text-xl font-light text-black bg-white px-3 py-1 border border-gray-200">
                  AGRI
                </div>
                <div className="text-xl font-light text-white bg-black px-3 py-1">
                  CRANDDR
                </div>
              </div>
            </div>
            <h1 className="text-xl font-semibold text-gray-900">
              Government Schemes
            </h1>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-6 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="mb-12">
            <h1 className="text-4xl font-light text-gray-900 mb-3">
              Government Schemes for Farmers
            </h1>
            <p className="text-lg text-gray-600 font-light">
              Explore and apply for various agricultural schemes and subsidies
            </p>
          </div>

          {/* Search and Filter */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search schemes..."
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
                />
              </div>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent bg-white"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Schemes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSchemes.map((scheme) => (
              <motion.div
                key={scheme.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 hover:shadow-lg transition-all"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium">
                        {scheme.category}
                      </span>
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium">
                        {scheme.state}
                      </span>
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {scheme.name}
                    </h3>
                  </div>
                  <FileText className="w-6 h-6 text-gray-400" />
                </div>

                <p className="text-gray-700 mb-4 leading-relaxed">
                  {scheme.description}
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        Eligibility
                      </p>
                      <p className="text-sm text-gray-600">
                        {scheme.eligibility}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        Benefits
                      </p>
                      <p className="text-sm text-gray-600">{scheme.benefits}</p>
                    </div>
                  </div>
                </div>

                <a
                  href={scheme.link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 w-full px-4 py-3 bg-black text-white rounded-lg hover:bg-gray-800 transition-colors font-medium"
                >
                  <ExternalLink className="w-5 h-5" />
                  Visit Official Website
                </a>
              </motion.div>
            ))}
          </div>

          {filteredSchemes.length === 0 && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
              <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                No schemes found
              </h3>
              <p className="text-gray-600">
                Try adjusting your search or filter criteria
              </p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
